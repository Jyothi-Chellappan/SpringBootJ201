package com.dao;

import org.springframework.beans.factory.annotation.Autowired;

import com.models.Doctor;
import com.repository.doctor1Repo;

public class DoctorDao {

	@Autowired
	doctor1Repo doc_rep;
	
	public Doctor saveDoctorDeatails(Doctor d){
		
		doc_rep.save(d);
		return d;
	}
	
}
