package com.models;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
public class Doctor {

	@Getter
	@Setter
	int id;
	@Getter
	@Setter
	String name;
	
	//@NoArgsConstructor
	
}
