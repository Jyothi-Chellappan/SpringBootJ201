package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.models.Doctor;
import com.service.Doctor_service;

@RestController
@RequestMapping("/api")
public class DoctorController {
	
	@Autowired
	Doctor_service doct_ser;
	
	@GetMapping("/doctor_display")
	public String displayDoctorDetails(){
		
		return "Welcome to Ortho Clinic!!!";
	}
	
	
	@PostMapping("/createDoc")
	public Doctor createDoctor(Doctor d){
	
		doct_ser.saveDoctor(d);
		return d;
	}
}
