package com.database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorPatientOnemanyLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorPatientOnemanyLombokApplication.class, args);
	}

}
////create model objects patient id,name,doctor...id,name