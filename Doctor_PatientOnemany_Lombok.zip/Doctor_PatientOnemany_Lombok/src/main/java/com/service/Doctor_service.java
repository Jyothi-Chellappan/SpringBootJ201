package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.DoctorDao;
import com.models.Doctor;

@Service
public class Doctor_service {
	
	@Autowired
	DoctorDao doct_dao;
	
	public Doctor saveDoctor(Doctor d){
		doct_dao.saveDoctorDeatails(d);
		return d;
	}

}
