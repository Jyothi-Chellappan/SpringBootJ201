package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.models.Doctor;

public interface doctor1Repo extends JpaRepository<Doctor,Integer> {

}
