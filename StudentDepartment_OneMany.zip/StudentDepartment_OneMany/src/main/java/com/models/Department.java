package com.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int did;
	private String dname;
  
 @OneToMany 
List <Student>no_students;

//constructors
public Department() {
	super();
}

public Department(int did, String dname, List<Student> no_students) {
	super();
	this.did = did;
	this.dname = dname;
	this.no_students = no_students;
}

public int getDid() {
	return did;
}

public void setDid(int did) {
	this.did = did;
}

public String getDname() {
	return dname;
}

public void setDname(String dname) {
	this.dname = dname;
}

public List<Student> getNo_students() {
	return no_students;
}

public void setNo_students(List<Student> no_students) {
	this.no_students = no_students;
}
	
 
 
 
}
