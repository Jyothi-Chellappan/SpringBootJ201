package com.database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDepartmentOneManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDepartmentOneManyApplication.class, args);
	}

}
