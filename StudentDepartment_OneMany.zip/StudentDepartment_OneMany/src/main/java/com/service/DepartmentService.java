package com.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.models.Department;
import com.repository.*;

public class DepartmentService{
	@Autowired
DepartmentRepository drepo;

public Department createDepartment(Department d){

             drepo.save(d);	
             return d;
}
}
