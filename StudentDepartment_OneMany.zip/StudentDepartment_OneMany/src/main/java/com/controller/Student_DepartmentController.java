package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.models.Department;
import com.models.Student;
import com.service.DepartmentService;
import com.service.StudentService;

@RestController
@RequestMapping("/student")
public class Student_DepartmentController {
	@Autowired
	StudentService stud_serv;
	@Autowired
	DepartmentService dept_serv;
	
	@GetMapping("/default")
	public String defaultMessage(){
			return "RestApI application started successfully!!!";
	}
			
	@PostMapping("/saveStud")
	public String saveStudent(Student s){
		
		stud_serv.createStudent(s);
		return "Student Saved Successfully";
	}
	
	@PostMapping("/saveDept")
	public String saveDepartment(Department d){
		
		dept_serv.createDepartment(d);
		return "Dept created successfully";
	}
	
	/*
	public String displayStudents(){
		
		return "";
	}
	
	
	
	public String displayDepartments(){
		
		return "";
	}
	*/
}
