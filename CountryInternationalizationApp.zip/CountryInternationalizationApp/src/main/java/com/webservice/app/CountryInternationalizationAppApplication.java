package com.webservice.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryInternationalizationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryInternationalizationAppApplication.class, args);
	}

}
