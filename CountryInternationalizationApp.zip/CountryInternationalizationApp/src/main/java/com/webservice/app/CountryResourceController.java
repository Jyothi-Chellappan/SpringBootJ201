package com.webservice.app;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CountryResourceController {

	    @Autowired
	    ResourceBundleMessageSource messageSource;   //Autowiring

	    @GetMapping("/getMessage")
	    public String getLocaleMessage(@RequestHeader(name="Accept-Language", required=false) Locale locale) {
	        return messageSource.getMessage("welcome.to.country",null,locale);
     	}
	 
	   @GetMapping("/")
	    public String getLocaleMessage2() {
	        return "messageSource";
     	}
	   //Other end-points
	}
