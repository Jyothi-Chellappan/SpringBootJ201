package com.webservice.EmployeeException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeExceptionApplication.class, args);
	}

}
