package com.webservice.product_EX_APP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductDetailsWsExcepApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductDetailsWsExcepApplication.class, args);
	}

}
