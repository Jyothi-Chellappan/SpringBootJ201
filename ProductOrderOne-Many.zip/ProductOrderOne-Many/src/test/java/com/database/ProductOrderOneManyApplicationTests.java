package com.database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductOrderOneManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
