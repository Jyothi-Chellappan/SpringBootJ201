package com.database.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.database.models.Products;

public interface ProductDao extends JpaRepository<Products, Integer> {

} // ProductDao class closing
