package com.database.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.database.models.Orders;

public interface OrderDao extends JpaRepository<Orders, Integer> {

} // OrderDao class  closing
